#include <sys/types.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>
#include <stdio.h>
#include <time.h>

const int input_size = 5000;

void read_data(char* name, char* file) {
    char buffer[input_size];
    int num = read(open(file, O_RDONLY), buffer, input_size);
    char length[10];
    sprintf(length, "%d", num);
    int fd;
    mknod(name, S_IFIFO | 0666, 0);
    fd = open(name, O_WRONLY);
    write(fd, length, 10);
    write(fd, buffer, num);
}

void write_data(char* name, char* file) {
    char size[10];
    int fd;
    mknod(name, S_IFIFO | 0666, 0);
    fd = open(name, O_RDONLY);
    read(fd, size, 10);
    int length;
    sscanf(size, "%d", &length);
    char buffer[length];
    read(fd, buffer, length);
    int output = open(file, O_WRONLY | O_CREAT);
    write(output, buffer, length);
}

void process_data(char* name_in, char* name_out, char* template, int sz) {
    char size[10];
    int fd_in;
    mknod(name_in, S_IFIFO | 0666, 0);
    fd_in = open(name_in, O_RDONLY);
    read(fd_in, size, 10);
    int length;
    sscanf(size, "%d", &length);
    char buffer[length];
    read(fd_in, buffer, length);
    int pos = 0;
    char buffer2[input_size * 11];
    for (int i = 0; i + sz - 1 < length; ++i) {
        int ok = 1;
        for (int j = 0; j < sz; ++j) {
            if (buffer[i + j] != template[j]) {
                ok = 0;
                break;
            }
        }
        if (ok == 1) {
            char t[10];
            int ci = i + 1, ppos = 0;
            while (ci) {
                t[ppos++] = (char)('0' + (ci % 10));
                ci /= 10;
            }
            --ppos;
            while (ppos > -1) {
                buffer2[pos++] = t[ppos--];
            }
            buffer2[pos++] = ' ';
        }
    }
    --pos;
    char buffer3[pos];
    for (int i = 0; i < pos; ++i) {
        buffer3[i] = buffer2[i];
    }
    char length2[10];
    sprintf(length2, "%d", pos);
    int fd_out;
    mknod(name_out, S_IFIFO | 0666, 0);
    fd_out = open(name_out, O_WRONLY);
    write(fd_out, length2, 10);
    write(fd_out, buffer3, pos);
}

int main(int argc, char **argv) {
    char* finput = "input stream";
    char* foutput = "output stream";
    if (fork() == 0) {
        read_data(finput, argv[1]);
    } else if (fork() == 0) {
        process_data(finput, foutput, argv[3], strlen(argv[3]));
    } else if (fork() == 0) {
        write_data(foutput, argv[2]);
    }
    return 0;
}
